// *******************************************************************
// * relay-control-server.c
// *
// *
// * Copyright 2012 by Ember Corporation. All rights reserved.              *80*
// *******************************************************************

#include "app/framework/include/af.h"

extern int8u emAllowRelay;

boolean emberAfRelayControlClusterGetRelayStateCallback(void)
{
  emberAfFillCommandRelayControlClusterGetRelayStateResponse(emAllowRelay);
  emberAfSendResponse();
  return TRUE;
}

boolean emberAfRelayControlClusterSetRelayStateCallback(boolean isEnabled,
                                                        int32u magicNumber)
{
  EmberAfStatus status = EMBER_ZCL_STATUS_NOT_AUTHORIZED;

  if (magicNumber == EMBER_AF_PLUGIN_RELAY_CONTROL_SERVER_MAGIC_NUMBER
      || EMBER_AF_PLUGIN_RELAY_CONTROL_SERVER_MAGIC_NUMBER == 0) {
    emAllowRelay = isEnabled;
    status = EMBER_ZCL_STATUS_SUCCESS;
  }

  emberAfSendImmediateDefaultResponse(status);
  return TRUE;
}
